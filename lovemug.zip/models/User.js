const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    name: { type: String, required: true },
    image: { type: String, default: null },
    country_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Country', required: true },
    gender: { type: String, enum: ['male', 'female', 'others'], required: true },
    fcm_token: { type: String, unique: true, default: null },
    auth_token: { type: String, unique: true, default: null },
    dob: { type: Date, required: true },
    status: { type: String, enum: ['active', 'inactive'], default: 'active' },
    is_creator: { type: Boolean, required: true },
    wallet_balance: { type: Number, default: 0.0 },
    created_at: { type: Date, default: Date.now }
});

module.exports = mongoose.model('User', userSchema);
